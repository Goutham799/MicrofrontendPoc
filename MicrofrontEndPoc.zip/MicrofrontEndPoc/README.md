# MicrofrontEndPoc



## Getting started

This project has been set up using mono repo.
## Why MonoRepo
- Easier to manage, since you don't need to worry about updating every other repo when changing one's version
- Sharing code is easier, we can add a project as another project's dependency
- Sharing the same node_modules for dependencies will save you a little space on your computer
#### more about monorepo: https://monorepo.tools/

### Setting up monorepo project
- First, you need to have lerna installed globally:

   `npm i -g lerna`
- create a git project and cd into the directory
 
  `lerna init`
- learn about yarn workspaces https://yarnpkg.com/features/workspaces

- configure lerna.json check what is included in the project

### Setting Up this project
- export the node options

    `export NODE_OPTIONS=--openssl-legacy-provider`
- execute `yarn install`
- execute `yarn start`
- browse `http://localhost:9000`
## Add your files

- [ ] [Create](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#create-a-file) or [upload](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#upload-a-file) files
- [ ] [Add files using the command line](https://docs.gitlab.com/ee/gitlab-basics/add-file.html#add-a-file-using-the-command-line) or push an existing Git repository with the following command:

```
cd existing_repo
git remote add origin https://gitlab.com/microfrontend5962201/MicrofrontEndPoc.git
git branch -M main
git push -uf origin main
```

## Integrate with your tools

- [ ] [Set up project integrations](https://gitlab.com/microfrontend5962201/MicrofrontEndPoc/-/settings/integrations)

## Collaborate with your team

- [ ] [Invite team members and collaborators](https://docs.gitlab.com/ee/user/project/members/)
- [ ] [Create a new merge request](https://docs.gitlab.com/ee/user/project/merge_requests/creating_merge_requests.html)
- [ ] [Automatically close issues from merge requests](https://docs.gitlab.com/ee/user/project/issues/managing_issues.html#closing-issues-automatically)
- [ ] [Enable merge request approvals](https://docs.gitlab.com/ee/user/project/merge_requests/approvals/)
- [ ] [Set auto-merge](https://docs.gitlab.com/ee/user/project/merge_requests/merge_when_pipeline_succeeds.html)

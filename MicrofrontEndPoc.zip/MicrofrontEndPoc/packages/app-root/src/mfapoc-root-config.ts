import { registerApplication, start } from 'single-spa';

registerApplication({
  name: '@mfapoc/home',
  app: () => System.import('@mfapoc/home'),
  activeWhen: (location) => !location.pathname.includes("login") && location.pathname === '/',
});

registerApplication({
  name: '@mfapoc/thome',
  app: () => System.import('@mfapoc/thome'),
  activeWhen: (location) => {
    return !location.pathname.includes("login") && location.pathname.includes("teacher")
  },
});

registerApplication({
  name: '@mfapoc/shome',
  app: () => System.import('@mfapoc/shome'),
  activeWhen: (location) => !location.pathname.includes("login") && location.pathname.includes("student"),
});

registerApplication({
  name: '@mfapoc/login-app',
  app: () => System.import('@mfapoc/login-app'),
  activeWhen: (location) => location.pathname.includes("login"),
});

start({
  urlRerouteOnly: true,
});

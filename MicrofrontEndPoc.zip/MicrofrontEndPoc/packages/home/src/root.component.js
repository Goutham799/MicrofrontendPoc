import { useEffect, useState } from "react";

export default function Root(props) {
  const [admin, setAdmin] = useState(false);
  const [appName, setAppName] = useState([]);

  const [shomeLoaded, setSHomeLoaded] = useState(false);
  const [tHomeLoaded, setTHomeLoaded] = useState(false);


  useEffect(() => {
    const storageEventListern = window.addEventListener("storage", () => {
      const loggedInUser = localStorage.getItem("loggedInUser");
      if (loggedInUser === null || loggedInUser === undefined) {
        props.singleSpa.getMountedApps()
          .filter(appName => appName?.indexOf("mounted") > -1)
          .forEach(appN => {
            console.log("unregistering -------------------------------", appN)
            props.singleSpa.unregisterApplication(appN);
          });
        const state = { loggedIn: false }
        //redirect the user to login micro front end
        window.history.pushState(state, "", "login")
      }
    })

    return () => {
      window.removeEventListener(storageEventListern)
    }
    // return () => {
    //   appName?.forEach(appN => props.singleSpa.unregisterApplication(appN));
    // }
  }, []);

  useEffect(() => {
    const loggedInUser = localStorage.getItem("loggedInUser");
    //check user in browser local storage
    console.log("logged in user in this application-----", loggedInUser);
    //if user is not present.. redirect the user to login ...
    if (loggedInUser === undefined || loggedInUser === null) {
      console.log("logged in user not found .. redirecting to login")
      const state = { loggedIn: false }
      //redirect the user to login micro front end
      window.history.pushState(state, "", "login")
    } else {
      if (loggedInUser === "tdemo") {
        const state = { loggedIn: false }
        //redirect the user to login micro front end
        window.history.pushState(state, "", "teacher")
      }
      if (loggedInUser === "sdemo") {
        const state = { loggedIn: false }
        //redirect the user to login micro front end
        window.history.pushState(state, "", "student")
      }
      if (loggedInUser === "admin") {
        setAdmin(true);
      }
    }
  }, [])
  return (
    <section>
      <div>Welcome Admin</div>
      <div>
        <button onClick={() => {
          if (tHomeLoaded === false) {
            const appNameTemp = '@mfapoc/thome' + Math.random();
            if (appName) {
              setAppName([...appName, appNameTemp]);
            } else {
              setAppName([appNameTemp]);
            }
            props?.singleSpa?.registerApplication({
              name: appNameTemp + "mounted",
              app: () => System.import('@mfapoc/thome'),
              activeWhen: (location) => {
                return true;
              },
            });
            setTHomeLoaded(true);
          }

        }}>Teacher Home</button>


        <button onClick={() => {
          if (shomeLoaded === false) {
            const appNameTemp = '@mfapoc/shome' + Math.random();
            if (appName) {
              setAppName([...appName, appNameTemp]);
            } else {
              setAppName([appNameTemp]);
            }
            props?.singleSpa?.registerApplication({
              name: appNameTemp + "mounted",
              app: () => System.import('@mfapoc/shome'),
              activeWhen: (location) => {
                return true;
              },
            });
            setSHomeLoaded(true);
          }
        }}>Student Home</button>

        <button value="logout" onClick={() => {
          const state = { loggedIn: false }
          localStorage.removeItem("loggedInUser");
          window.dispatchEvent(new Event("storage"));
          window.history.pushState(state, "", "/")
        }}>Logout</button>
      </div>

    </section>
  );
}

import React, { useState } from 'react';
export default function Root(props) {
  const [userName, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState();

  return (<section style={{
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    zoom: '200%'
  }}>
    <div style={{ display: 'flex', justifyContent: 'center' }}>
      <div style={{ display: 'flex', flexDirection: "column", gap: "15px" }}>
        <div>
          <span style={{ width: '100px', display: 'inline-block' }}>Login Id: </span>
          <input type="text" name="username" id="username" onChange={(e) => { setUsername(e.target.value) }} value={userName} />
        </div>
        <div>
          <span style={{ width: '100px', display: 'inline-block' }}>Password: </span>
          <input type="password" name="userpass" id="userpass" onChange={(e) => { setPassword(e.target.value) }} value={password} />
        </div>
        <div style={{ display: 'flex', gap: "15px" }}>
          <input type="button" value="login" style={{ width: "100px" }} onClick={() => {
            if (userName === "tdemo" || userName === "sdemo" || userName === "admin") {
              //set this thing in local storage
              const state = { loggedIn: true }
              localStorage.setItem("loggedInUser", userName);
              window.history.pushState(state, "", "/")
            } else {
              setErrorMessage("Invalid Credentials")
            }
          }} />

          <input type="button" value="reset" style={{ width: "100px" }} onClick={() => {
            setUsername("");
            setPassword("");
            setErrorMessage(undefined);
          }} />
        </div>

        {errorMessage && <span style={{
          color: "red",
          fontSize: "9px",
          width: "260px"
        }}>{errorMessage}</span>}
      </div>
    </div>
  </section>);
}

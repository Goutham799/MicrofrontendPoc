import React from 'react';
export default function Root(props) {
  const [username, setUsername] = React.useState("");
  const loggedInUser = localStorage.getItem("loggedInUser");
  React.useEffect(() => {
    //check user in browser local storage
   
    console.log("logged in user in this application-----", loggedInUser);
    //if user is not present.. redirect the user to login ...
    if (loggedInUser === undefined || loggedInUser === null) {
      console.log("logged in user not found .. redirecting to login")
      const state = { loggedIn: false }
      //redirect the user to login micro front end
      window.history.pushState(state, "", "login")
    } else {
      setUsername(loggedInUser);
      if (loggedInUser === "tdemo") {
        const state = { loggedIn: false }
        //redirect the user to login micro front end
        window.history.pushState(state, "", "teacher")
      }
    }
  }, [])

  return (
    <section style={{
      zoom: "200%",
      fontSize: "large",
      textTransform: "capitalize"
    }}>
      welcome
      <span style={{
        color: "red",
        textTransform: "uppercase",
        padding: "5px",
        fontWeight: "900"
      }}>Student</span><br></br>

      {loggedInUser === "sdemo" && <button value="logout" onClick={() => {
        const state = { loggedIn: false }
        localStorage.removeItem("loggedInUser");
        window.dispatchEvent(new Event("storage"));
        window.history.pushState(state, "", "/")
      }}>Logout</button>}</section>
  );
}
